﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public GameObject brickPrefab;
    public GameObject emptyBrickPrefab;

    public int generatorComplexity = 200;
    public int movesNumber = 0;
    public float time = 0f;
    bool gameEnd = false;

    GameObject[,] bricks = new GameObject[4, 4];
    GameObject[] brickList = new GameObject[16];

    BrickController emptyBrick;
    // Start is called before the first frame update
    void Start()
    {
        initBricks();
        generate16();
    }

    // Update is called once per frame
    void Update()
    {
        
        if (!gameEnd)
        {
            time += Time.deltaTime;
            isGameEnd();
        }
        if (!gameEnd)
        {
            moveBricks();
        }
        if (Input.GetKeyDown("o"))
        {
            newGame();
        }

    }
    void initBricks()
    {
        GameObject go;
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                Vector3 pos = new Vector3(-3 + 2 * i, 0.5f, 3 - 2 * j);
                if (i == 3 && j == 3)
                {
                    go = Instantiate(emptyBrickPrefab, pos, Quaternion.identity);
                }
                else
                {
                    go = Instantiate(brickPrefab, pos, Quaternion.identity);
                    go.GetComponentInChildren<TMP_Text>().text = (4 * j + i + 1).ToString();

                }
                BrickController brickController = go.GetComponent<BrickController>();
                brickController.setCor(new Vector2Int(j, i));
                brickController.number = 4 * j + i + 1;

                bricks[j, i] = go;
                brickList[4 * j + i] = go;
            }
        }
        emptyBrick = bricks[3, 3].GetComponent<BrickController>();
    }
    void generate16()
    {
        
        for (int x = 0; x < generatorComplexity; x++)
        {
            int i = emptyBrick.getCor()[0], j = emptyBrick.getCor()[1];
            int dir = Random.Range(1, 5);
            if (dir == 1 && i > 0)
            {
                swapBricks(emptyBrick, bricks[i - 1, j].GetComponent<BrickController>(), true);
            }
            else if (dir == 2 && i < 3)
            {
                swapBricks(emptyBrick, bricks[i + 1, j].GetComponent<BrickController>(), true);
            }
            else if (dir == 3 && j > 0)
            {
                swapBricks(emptyBrick, bricks[i, j - 1].GetComponent<BrickController>(), true);
            }
            else if (dir == 4 && j < 3)
            {
                swapBricks(emptyBrick, bricks[i, j + 1].GetComponent<BrickController>(), true);
            }
        }
    }
    void isGameEnd()
    {
        if (bricks[0, 0].GetComponent<BrickController>().number == 1 &&
            bricks[0, 1].GetComponent<BrickController>().number == 2 &&
            bricks[0, 2].GetComponent<BrickController>().number == 3 &&
            bricks[0, 3].GetComponent<BrickController>().number == 4 &&
            bricks[1, 0].GetComponent<BrickController>().number == 5 &&
            bricks[1, 1].GetComponent<BrickController>().number == 6 &&
            bricks[1, 2].GetComponent<BrickController>().number == 7 &&
            bricks[1, 3].GetComponent<BrickController>().number == 8 &&
            bricks[2, 0].GetComponent<BrickController>().number == 9 &&
            bricks[2, 1].GetComponent<BrickController>().number == 10 &&
            bricks[2, 2].GetComponent<BrickController>().number == 11 &&
            bricks[2, 3].GetComponent<BrickController>().number == 12 &&
            bricks[3, 0].GetComponent<BrickController>().number == 13 &&
            bricks[3, 1].GetComponent<BrickController>().number == 14 &&
            bricks[3, 2].GetComponent<BrickController>().number == 15)
        {
            gameEnd = true;
            Debug.Log("Game has ended!");
        }
    }
    void newGame()
    {
        time = 0;
        movesNumber = 0;
        gameEnd = false;
        foreach(GameObject brick in brickList)
        {
            Destroy(brick);
        }
        initBricks();
        generate16();
    }
    void moveBricks()
    {
        if (Input.GetKeyDown("w"))
        {
            int x = emptyBrick.getCor()[0], y = emptyBrick.getCor()[1];
            if (x > 0)
            {
                swapBricks(emptyBrick, bricks[x - 1, y].GetComponent<BrickController>());
                movesNumber++;
            }
        }
        if (Input.GetKeyDown("s"))
        {
            int x = emptyBrick.getCor()[0], y = emptyBrick.getCor()[1];
            if (x < 3)
            {
                swapBricks(emptyBrick, bricks[x + 1, y].GetComponent<BrickController>());
                movesNumber++;
            }
        }
        if (Input.GetKeyDown("a"))
        {
            int x = emptyBrick.getCor()[0], y = emptyBrick.getCor()[1];
            if (y > 0)
            {
                swapBricks(emptyBrick, bricks[x, y - 1].GetComponent<BrickController>());
                movesNumber++;
            }
        }
        if (Input.GetKeyDown("d"))
        {
            int x = emptyBrick.getCor()[0], y = emptyBrick.getCor()[1];
            if (y < 3)
            {
                swapBricks(emptyBrick, bricks[x, y + 1].GetComponent<BrickController>());
                movesNumber++;
            }
        }
    }
    void swapBricks(BrickController brickA, BrickController brickB, bool instant=false)
    {
        // Change pointers in grid
        bricks[brickA.getCor()[0], brickA.getCor()[1]] = brickB.gameObject;
        bricks[brickB.getCor()[0], brickB.getCor()[1]] = brickA.gameObject;

        // Change coordinates in BrickController
        Vector2Int corAux = brickA.getCor();
        brickA.setCor(brickB.getCor());
        brickB.setCor(corAux);

        // Change bricks destinations
        if (!instant)
        {
            Vector3 aux = brickA.destination;
            brickA.SetNewDestination(brickB.destination);
            brickB.SetNewDestination(aux);
        }
        else
        {
            Vector3 aux = brickA.transform.position;
            brickA.transform.position = brickB.transform.position;
            brickB.transform.position = aux;
        }
        
    }
}
