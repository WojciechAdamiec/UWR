﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Moves : MonoBehaviour
{
    public Text moveText;
    public GameManager mng;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        moveText.text = "Moves: " + mng.movesNumber.ToString();
    }
}
