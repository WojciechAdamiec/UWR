﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BrickController : MonoBehaviour
{
    public float speed;
    public Vector3 destination;
    Vector2Int cor;
    public int number;

    // Start is called before the first frame update
    void Start()
    {
        destination = transform.position;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        transform.position = Vector3.Lerp(transform.position, destination, speed * Time.deltaTime);
    }

    public void SetNewDestination(Vector3 newDestination)
    {
        destination = newDestination;
    }

    public void setCor(Vector2Int newCor)
    {
        cor = newCor;
    }

    public Vector2Int getCor()
    {
        return cor;
    }
}
