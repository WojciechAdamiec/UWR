﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public float pickupDuration = 6;
    public Vector4 gameBounds = new Vector4(-10, 10, -10, 10);
    public Vector4 spawnBounds = new Vector4(-8, 8, -8, 8);
    public float minTimeBetweenPickups = 3;
    public float maxTimeBetweenPickups = 12;
    public GameObject[] pickupPrefabs;
    public GameObject playerPrefab;

    public Text scoreBoard;

    float timePassed = 0.0f;
    float timeUntillPickup;
    List<GameObject> players; 

    public void Start(){
        timeUntillPickup = Random.Range(minTimeBetweenPickups, maxTimeBetweenPickups);
        players = new List<GameObject>();
        for(int i=0; i<4; i++){
            if (PlayerSettings.enabledToggles[i]){
                Vector2 spawnPos = randomPoint(spawnBounds);
                GameObject player = Instantiate(playerPrefab, spawnPos, Quaternion.identity);
                players.Add(player);
                Wurm wurm = player.transform.GetChild(0).transform.GetComponent<Wurm>();
                Tail tail = player.transform.GetChild(0).transform.GetComponent<Tail>();
                tail.color = PlayerSettings.colors[i];
                wurm.playerName = PlayerSettings.names[i];
                wurm.inputAxis = (i+1).ToString();
                wurm.id = i;
                wurm.transform.Rotate(Vector3.forward * Random.Range(0f, 360f));
            }
        }

    }

    public void endGame()
    {
        foreach(GameObject player in players)
        {
            Wurm wurm = player.transform.GetChild(0).transform.GetComponent<Wurm>();
            if (wurm.alive)
            {
                PlayerSettings.scores[wurm.id] += 1;
            }
        }
        Debug.Log("Player Dead!");
        Round();

    }

    public void Update(){
        timePassed += Time.deltaTime;

        if(timePassed > timeUntillPickup){
            Debug.Log(timeUntillPickup);
            timePassed -= timeUntillPickup;
            spawnPickup();
            timeUntillPickup = Random.Range(minTimeBetweenPickups, maxTimeBetweenPickups);
        }

        updateUI();
    }

    void spawnPickup(){
        int pickupType = Random.Range(0, pickupPrefabs.Length);
        GameObject pickup = Instantiate(pickupPrefabs[pickupType], randomPoint(gameBounds), Quaternion.identity);
        Destroy(pickup, pickupDuration * 2);
    }

    Vector2 randomPoint(Vector4 bounds){
        float x = Random.Range(bounds.x, bounds.y);
        float y = Random.Range(bounds.z, bounds.w);
        return new Vector2(x,y);
    }

    public void useAbility(string ability, Transform player){
        List<Transform> others = new List<Transform>();

        foreach (GameObject obj in players){
            if(obj.transform.GetChild(0).transform != player)
                others.Add(obj.transform.GetChild(0).transform);
        }

        switch(ability){
            case "growglobal":
                foreach (Transform p in others){
                    p.GetComponent<Tail>().grow();
                    p.GetComponent<Wurm>().grow();
                    p.GetComponent<Tail>().Invoke("shrink", pickupDuration);
                    p.GetComponent<Wurm>().Invoke("shrink", pickupDuration);
                }
                break;
            case "growself":
                player.GetComponent<Tail>().grow();
                player.GetComponent<Wurm>().grow();
                player.GetComponent<Tail>().Invoke("shrink", pickupDuration);
                player.GetComponent<Wurm>().Invoke("shrink", pickupDuration);
                break;
            case "shrinkglobal":
                foreach (Transform p in others){
                    p.GetComponent<Tail>().shrink();
                    p.GetComponent<Wurm>().shrink();
                    p.GetComponent<Tail>().Invoke("grow", pickupDuration);
                    p.GetComponent<Wurm>().Invoke("grow", pickupDuration);
                }
                break;
            case "shrinkself":
                player.GetComponent<Tail>().shrink();
                player.GetComponent<Wurm>().shrink();
                player.GetComponent<Tail>().Invoke("grow", pickupDuration);
                player.GetComponent<Wurm>().Invoke("grow", pickupDuration);
                break;
            case "slowglobal":
                foreach (Transform p in others){
                    p.GetComponent<Wurm>().slowDown();
                    p.GetComponent<Wurm>().Invoke("speedUp", pickupDuration);
                }
                break;
            case "slowself":
                player.GetComponent<Wurm>().slowDown();
                player.GetComponent<Wurm>().Invoke("speedUp", pickupDuration);
                break;
            case "speedglobal":
                foreach (Transform p in others){
                    p.GetComponent<Wurm>().speedUp();
                    p.GetComponent<Wurm>().Invoke("slowDown", pickupDuration);
                }
                break;
            case "speedself":
                    player.GetComponent<Wurm>().speedUp();
                    player.GetComponent<Wurm>().Invoke("slowDown", pickupDuration);
                break;
        }
    }

    void updateUI()
    {
        string aux = "";
        foreach(GameObject player in players)
        {
            Wurm wurm = player.transform.GetChild(0).transform.GetComponent<Wurm>();
            aux += PlayerSettings.names[wurm.id] + ": ";
            aux += PlayerSettings.scores[wurm.id];
            aux += "\n";
        }
        scoreBoard.text = aux;
    }

    void Round()
    {
        if (isRoundOver())
        {
            Invoke("restart", 4);
            Debug.Log("Round End!");
            foreach (GameObject player in players)
            {
                Wurm wurm = player.transform.GetChild(0).transform.GetComponent<Wurm>();
                if (wurm.alive)
                {
                    wurm.speed = 0f;
                    wurm.rotationSpeed = 0f;
                    break;
                }
            }
        }
    }
    bool isRoundOver()
    {
        int alive = 0;
        foreach (GameObject player in players)
        {
            Wurm wurm = player.transform.GetChild(0).transform.GetComponent<Wurm>();
            if (wurm.alive)
            {
                alive += 1;
            }
        }
        return alive <= 1;
    }
    void restart()
    {
        SceneManager.LoadScene(2);
    }
    
}
