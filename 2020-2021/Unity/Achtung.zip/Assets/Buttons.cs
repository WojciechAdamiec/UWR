﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Buttons : MonoBehaviour
{
    public Toggle[] enabledToggles;
    public Text[] names;
    public Toggle[] AIToggles;
    public Image[] colors;

    public void PlayGame()
    {
        PlayerSettings.enabledToggles = new bool[4];
        PlayerSettings.names = new string[4];
        PlayerSettings.AIToggles = new bool[4];
        PlayerSettings.colors = new Color[4];
        PlayerSettings.scores = new int[4];
        for(int i=0;i<4;i++){
            PlayerSettings.enabledToggles[i] = enabledToggles[i].isOn;
            PlayerSettings.names[i] = names[i].text;
            PlayerSettings.AIToggles[i] = AIToggles[i].isOn;
            PlayerSettings.colors[i] = colors[i].color;
        }

        SceneManager.LoadScene(2);
    }

    public void Next()
    {
        SceneManager.LoadScene(1);
    }

    public void ExitGame()
    {
        SceneManager.LoadScene(1);
    }

    public void Back()
    {
        SceneManager.LoadScene(0);
    }
    public void QuitGame()
    {
        Application.Quit();
    }
}
