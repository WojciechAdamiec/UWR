﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class PlayerSettings
{
    public static int[] scores;
    public static bool[] enabledToggles;
    public static string[] names;
    public static bool[] AIToggles;
    public static Color[] colors;
}
