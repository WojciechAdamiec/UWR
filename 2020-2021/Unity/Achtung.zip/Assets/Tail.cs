﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Tail : MonoBehaviour
{
    public float pointSpacing = .1f;
    public Color color = Color.red;
    public float width = .1f;
    public int verticesInSegment =  15;
    public float emptySegmentDistance = .8f;

    List<LineRenderer> lines;
    List<EdgeCollider2D> colliders;

    List<Vector2> currentPoints;
    LineRenderer currentLine;
    EdgeCollider2D currentCollider;
    Transform wurm;
    float[] factors = {1/4f, 1/3f, 1/2f, 1, 2, 3, 4};
    int scaleIndex = 3;
    float currentWidth;
    float currentSpacing;

    Material lineMaterial;

    void Start(){
        wurm = transform;
        lines = new List<LineRenderer>();
        colliders = new List<EdgeCollider2D>();
        lineMaterial = new Material(Shader.Find("Legacy Shaders/Particles/Alpha Blended Premultiply"));

        currentWidth = width * factors[scaleIndex];
        newSegment();
        SetPoint();
    }

    
    void Update(){
        currentWidth = width * factors[scaleIndex];
        if (Vector3.Distance(currentPoints.Last(), wurm.position) > pointSpacing) {
            SetPoint(); 
        }
    }

    void newSegment(){
        if (currentPoints != null)
            currentCollider.points = currentPoints.ToArray<Vector2>();
        lines.Add(currentLine);
        colliders.Add(currentCollider);

        GameObject obj = new GameObject("TailSegment" + lines.Count);
        obj.transform.parent = transform.parent;
        obj.tag = "killer";

        currentLine = obj.AddComponent<LineRenderer>();
        currentLine.numCapVertices = 5;
        currentLine.numCornerVertices = 5;
        currentLine.startColor = color;
        currentLine.endColor = color;
        currentLine.material = lineMaterial;
        currentLine.startWidth = currentWidth;
        currentLine.endWidth = currentWidth;

        currentCollider = obj.AddComponent<EdgeCollider2D>();
        currentPoints = new List<Vector2>();
    }

    void SetPoint(){
        if (currentPoints.Count < verticesInSegment){
            if (currentPoints.Count > 2){
                List<Vector2> collisionPoints = new List<Vector2>(currentPoints);
                collisionPoints.RemoveAt(currentPoints.Count - 1);
                currentCollider.points = collisionPoints.ToArray<Vector2>();
            }
            
            currentPoints.Add(wurm.position);
            currentLine.positionCount = currentPoints.Count;
            currentLine.SetPosition(currentPoints.Count - 1, wurm.position);
        }
        else if(Vector3.Distance(currentPoints.Last(), wurm.position) > emptySegmentDistance){
            newSegment();
            SetPoint();
        }
    }

    void OnDestroy(){
        Destroy(lineMaterial);
    }

    public void grow(){
        scaleIndex++;
    }

    public void shrink(){
        scaleIndex--;
    }

 }
