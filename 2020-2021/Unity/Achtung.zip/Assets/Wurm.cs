﻿using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wurm : MonoBehaviour
{
    public float speed = 3f;
    public float rotationSpeed = 200f;
    public string playerName = "Player";
    public string inputAxis;

    public int id;
    public bool alive;

    float horizontal = 0f;
    string[] abilities = {"growglobal", "growself", "shrinkglobal", "shrinkself", "slowglobal", "slowself", "speedglobal", "speedself"};
    float[] factors = {1/4f, 1/3f, 1/2f, 1, 2, 3, 4};
    int speedIndex = 3;
    int scaleIndex = 3;
    float currentSpeed;

    private void Start()
    {
        alive = true;
    }
    void Update()
    {
        horizontal = Input.GetAxisRaw(inputAxis);
        currentSpeed = speed * factors[speedIndex];
    }

    void FixedUpdate()
    {
        transform.Translate(Vector2.up * currentSpeed * Time.fixedDeltaTime, Space.Self);
        transform.Rotate(Vector3.forward * rotationSpeed * -horizontal * Time.fixedDeltaTime);
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("Collided with " + collision.gameObject.name);
        if (collision.tag == "killer" && alive)
        {
            speed = 0f;
            rotationSpeed = 0f;
            alive = false;
            GameObject.FindObjectOfType<GameManager>().endGame();
        }
        else{
            string match = abilities.FirstOrDefault(str => str.Contains(collision.tag));
            if(match != null){
                GameObject.FindObjectOfType<GameManager>().useAbility(match, transform);
                Destroy(collision.gameObject);
            }

        }
    }

    public void speedUp(){
        speedIndex++;
    }

    public void slowDown(){
        speedIndex--;
    }

    public void grow(){
        scaleIndex++;
        transform.localScale = new Vector3(factors[scaleIndex],factors[scaleIndex],factors[scaleIndex]);
    }

    public void shrink(){
        scaleIndex--;
        transform.localScale = new Vector3(factors[scaleIndex],factors[scaleIndex],factors[scaleIndex]);
    }

}
