﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    // Camera speed and drift time
    public float normalSpeed;
    public float fastSpeed;
    public float movementTime;

    // Camera rotation
    public float rotationAmount;
    public float rotationTime;

    // Camera Zoom
    public Transform cameraTransform;
    public Vector3 zoomAmount;
    public float zoomTime;
    public Vector3 zoomMaximum;
    public Vector3 zoomMinimum;
    public float zoomMouseSensitivity;

    // Mouse camera control
    public Vector3 dragStartPosition;
    public Vector3 dragCurrentPosition;
    public Vector3 rotateStartPosition;
    public Vector3 rotateCurrentPosition;

    // Auxiliary variables
    public float movementSpeed;
    public Vector3 newPosition;
    public Quaternion newRotation;
    public Vector3 newZoom;
    public float moveScaling;
    public float moveScalingLimit;

    // Start is called before the first frame update
    void Start()
    {
        newPosition = transform.position;
        newRotation = transform.rotation;
        newZoom = cameraTransform.localPosition;
    }

    // Update is called once per frame
    void Update()
    {
        HandleMouseInput();
        HandleMovementInput();
    }

    void HandleMouseInput()
    {
        if (Input.mouseScrollDelta.y != 0)
        {
            if (newZoom.y + Input.mouseScrollDelta.y * zoomMouseSensitivity * zoomAmount.y < zoomMinimum.y)
            {
                newZoom = zoomMinimum;
            }
            else if (newZoom.y + Input.mouseScrollDelta.y * zoomMouseSensitivity * zoomAmount.y > zoomMaximum.y)
            {
                newZoom = zoomMaximum;
            }
            else
            {
                newZoom += Input.mouseScrollDelta.y * zoomMouseSensitivity * zoomAmount;
            }
        }
        
        if (Input.GetMouseButtonDown(2))
        {
            rotateStartPosition = Input.mousePosition;
        }
        if (Input.GetMouseButton(2))
        {
            rotateCurrentPosition = Input.mousePosition;
            Vector3 difference = rotateStartPosition - rotateCurrentPosition;
            rotateStartPosition = rotateCurrentPosition;
            newRotation *= Quaternion.Euler(Vector3.up * (-difference.x / 5f));
        }
    }

    void HandleMovementInput()  // TODO: make seperate file for all controls
    {
        if (newZoom.y / zoomMaximum.y < moveScalingLimit)
        {
            moveScaling = moveScalingLimit;
        }
        else
        {
            moveScaling = newZoom.y / zoomMaximum.y;
        }
        if (Input.GetKey(KeyCode.LeftShift))
        {
            movementSpeed = fastSpeed;
        }
        else
        {
            movementSpeed = normalSpeed;
        }

        if (Input.GetKey(KeyCode.W))
        {
            newPosition += transform.forward * movementSpeed * moveScaling;
        }
        if (Input.GetKey(KeyCode.A))
        {
            newPosition -= transform.right * movementSpeed * moveScaling;
        }
        if (Input.GetKey(KeyCode.S))
        {
            newPosition -= transform.forward * movementSpeed * moveScaling;
        }
        if (Input.GetKey(KeyCode.D))
        {
            newPosition += transform.right * movementSpeed * moveScaling;
        }

        if (Input.GetKey(KeyCode.Q))
        {
            newRotation *= Quaternion.Euler(Vector3.up * rotationAmount);
        }
        if (Input.GetKey(KeyCode.E))
        {
            newRotation *= Quaternion.Euler(Vector3.up * -rotationAmount);
        }

        if (Input.GetKey(KeyCode.R))
        {
            if (newZoom.y + zoomAmount.y < zoomMinimum.y)
            {
                newZoom = zoomMinimum;
            }
            else
            {
                newZoom += zoomAmount;
            }
        }
        if (Input.GetKey(KeyCode.F))
        {
            if (newZoom.y + zoomAmount.y > zoomMaximum.y)
            {
                newZoom = zoomMaximum;
            }
            else
            {
                newZoom -= zoomAmount;
            }
        }

        transform.position = Vector3.Lerp(transform.position, newPosition, Time.deltaTime * movementTime);
        transform.rotation = Quaternion.Lerp(transform.rotation, newRotation, Time.deltaTime * rotationTime);
        cameraTransform.localPosition = Vector3.Lerp(cameraTransform.localPosition, newZoom, Time.deltaTime * zoomTime);
    }
}
