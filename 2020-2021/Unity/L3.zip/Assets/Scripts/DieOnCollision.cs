﻿using UnityEngine;
public class DieOnCollision : MonoBehaviour
{
    public GameObject dead;
    public Light blaze;

    private int flag = 0;

    private void Start()
    {
        blaze.range = 25 * transform.localScale[0] / 15;
    }
    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.CompareTag("FireBall"))
        {
            Vector3 size = gameObject.transform.localScale;
            Vector3 speed = gameObject.GetComponent<Rigidbody>().velocity;
            
            Destroy(gameObject);
            flag += 1;
            if (flag == 1)
            {
                GameObject corpse = Instantiate(dead, transform.position, transform.rotation);
                corpse.transform.localScale = size;
            }
        }
        
    }
}