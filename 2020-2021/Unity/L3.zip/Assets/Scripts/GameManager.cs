﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public GameObject cameraRig;
    public CannonController cannonController;
    public GameObject cannonCamera;
    bool lockCannon = false;

    void Start()
    {
        initCamera();
    }

    void Update()
    {
        if (Input.GetKeyDown("x"))
        {
            switchCannon();
        }
    }

    void initCamera()
    {
        cameraRig.SetActive(false);
        cannonCamera.SetActive(true);
    }

    void switchCannon()
    {
        switchCamera();
        lockCannon = !lockCannon;
        cannonController.enabled = !cannonController.enabled;
    }
    void switchCamera()
    {
        cameraRig.SetActive(!cameraRig.activeSelf);
        cannonCamera.SetActive(!cannonCamera.activeSelf);
    }

}
