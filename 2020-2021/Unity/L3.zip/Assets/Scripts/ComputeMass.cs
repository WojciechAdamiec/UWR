﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ComputeMass : MonoBehaviour
{
    public Rigidbody body;
    public float massModifier;
    private float mass;

    void Start()
    {
        mass = (transform.localScale[0] * transform.localScale[1] * transform.localScale[2]) * massModifier;
        body.mass = mass;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
