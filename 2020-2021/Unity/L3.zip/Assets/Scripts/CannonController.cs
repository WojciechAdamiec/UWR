﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CannonController : MonoBehaviour
{
    public Transform Base;
    public Transform Cannon;
    public Quaternion horizontalDestination;
    public Vector3 verticalDestination;
    public GameObject ballExit;
    public float rotationAmount;
    public float rotationTime;
    public float verticalAmount;
    public float verticalDump = 0.9f;
    public float maxUpRotation = 30;
    public float maxDownRotation = -30;

    public float cooldownTime;
    private float nextFireTime = 0f;

    public float startingBalls;
    public float balls;

    public GameObject ball;
    public float ballSpeed;

    void Start()
    {
        horizontalDestination = transform.rotation;
        verticalDestination = Cannon.rotation.eulerAngles;
        balls = startingBalls;
    }

    void FixedUpdate()
    {
        if (Input.GetKey(KeyCode.W))
        {
            verticalDestination = Vector3.left * verticalAmount;
        }

        if (Input.GetKey(KeyCode.S))
        {
            verticalDestination = Vector3.left * -verticalAmount;
        }
        
        if (Input.GetKey(KeyCode.A))
        {
            horizontalDestination *= Quaternion.Euler(Vector3.down * rotationAmount);
        }

        if (Input.GetKey(KeyCode.D))
        {
            horizontalDestination *= Quaternion.Euler(Vector3.down * -rotationAmount);
        }

        verticalDestination *= verticalDump;
        Cannon.Rotate(verticalDestination);
        transform.rotation = Quaternion.Lerp(transform.rotation, horizontalDestination, Time.deltaTime * rotationTime);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            fire();
        }
        
    }
    void fire()
    {
        if (Time.time > nextFireTime && balls > 0)
        {
            Transform copy = ballExit.transform;
            GameObject b = Instantiate(ball, copy.position, Quaternion.identity);
            b.GetComponent<Rigidbody>().velocity = ballExit.transform.forward * ballSpeed;
            nextFireTime = Time.time + cooldownTime;
            balls -= 1;
        }
        
    }
}
