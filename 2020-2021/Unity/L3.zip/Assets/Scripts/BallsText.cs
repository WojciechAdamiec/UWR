﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BallsText : MonoBehaviour
{
    public Text balls;
    public CannonController cannonController;

    void Start()
    {
        
    }

    void Update()
    {
        balls.text = "Cannon balls: " + cannonController.balls.ToString();
    }
}
