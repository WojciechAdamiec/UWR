const example = 'example string';
console.log(example.length);