var pets = ['cat', 'dog', 'rat'];
for (var x = 0; x < 3; x++){
    pets[x] = pets[x] + 's';
}
console.log(pets);