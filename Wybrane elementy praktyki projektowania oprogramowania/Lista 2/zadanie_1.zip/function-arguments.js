function math (a, b, c){
    return b * c + a;
}
console.log(math(53, 61, 67));